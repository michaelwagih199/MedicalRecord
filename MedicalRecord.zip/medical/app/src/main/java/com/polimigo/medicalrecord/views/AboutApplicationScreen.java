package com.polimigo.medicalrecord.views;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.polimigo.medicalrecord.R;

public class AboutApplicationScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_application_screen);
    }
}