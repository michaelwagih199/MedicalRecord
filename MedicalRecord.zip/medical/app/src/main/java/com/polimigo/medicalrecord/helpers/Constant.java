package com.polimigo.medicalrecord.helpers;

public class Constant {
    public static final String saveFlag ="SAVE";
    public static final String updateFlag = "update";
}
