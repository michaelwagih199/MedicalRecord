package com.polimigo.medicalrecord.repositories;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.polimigo.medicalrecord.helpers.SharedPrefrenceHelper;
import com.polimigo.medicalrecord.helpers.ToastMessage;
import com.polimigo.medicalrecord.models.PatientModel;
import com.polimigo.medicalrecord.models.Users;
import com.polimigo.medicalrecord.views.patient.PatientHomeScreen;
import com.polimigo.medicalrecord.views.doctor_screen.DoctorScreen;
import com.polimigo.medicalrecord.views.login_screen.LoginScreen;


public class UsersRepository {

    /* ContactsFirestoreManager object **/
    private static UsersRepository usersRepository;

    private FirebaseFirestore firebaseFirestore;
    private CollectionReference contactsCollectionReference;
    SharedPrefrenceHelper sharedPrefrenceHelper = new SharedPrefrenceHelper();


    public static UsersRepository newInstance() {
        if (usersRepository == null) {
            usersRepository = new UsersRepository();
        }
        return usersRepository;
    }


    private UsersRepository() {
        firebaseFirestore = FirebaseFirestore.getInstance();
        contactsCollectionReference = firebaseFirestore.collection("users");
    }

    public boolean createDocument(Users contact) {
        final boolean[] result = {true};
        contactsCollectionReference.add(contact).addOnCompleteListener(command -> {
            Log.d("dddd", "" + command.isSuccessful());
            if (command.isSuccessful())
                result[0] = true;
            if (command.isCanceled())
                result[0] = false;
        });
        Log.d("resss", "" + result[0]);
        return result[0];
    }

    public void getAllContacts(OnCompleteListener<QuerySnapshot> onCompleteListener) {
        contactsCollectionReference.get().addOnCompleteListener(onCompleteListener);
    }

    public void updateContact(Users contact) {
        String documentId = contact.getDocumentId();
        DocumentReference documentReference = contactsCollectionReference.document(documentId);
        documentReference.set(contact);
    }

    public void deleteContact(String documentId) {
        DocumentReference documentReference = contactsCollectionReference.document(documentId);
        documentReference.delete();
    }

    public void isUser(final String userName, String password, final String userType, final Context context) {
        boolean isUser = false;
        contactsCollectionReference
                .whereEqualTo("userType", userType)
                .whereEqualTo("userName", userName)
                .whereEqualTo("password", password)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.getResult().isEmpty()) {
                        Intent i = new Intent(context.getApplicationContext(), LoginScreen.class);
                        context.startActivity(i);
                        ToastMessage.addMessage("check user name or password", context);
                        ((Activity) context).finish();
                    }
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            if (document.getData().isEmpty()) {
                                ToastMessage.addMessage("check user name or password", context);
                            } else {
                                if (userType.equals("patient")) {
                                    Intent i = new Intent(context.getApplicationContext(), PatientHomeScreen.class);
                                    sharedPrefrenceHelper.setUsername(context, userName);
                                    sharedPrefrenceHelper.setNationalId(context,document.getData().get("nationalId").toString());
                                    context.startActivity(i);
                                    ((Activity) context).finish();
                                }
                                if (userType.equals("doctor")) {
                                    Intent i = new Intent(context.getApplicationContext(), DoctorScreen.class);
                                    sharedPrefrenceHelper.setUsername(context, userName);
                                    context.startActivity(i);
                                    ((Activity) context).finish();
                                }

                            }
                        }
                    }
                });


    }


}
