package com.polimigo.medicalrecord.views.patient;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.polimigo.medicalrecord.R;

public class NearestDoctor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearest_doctor);
    }

}