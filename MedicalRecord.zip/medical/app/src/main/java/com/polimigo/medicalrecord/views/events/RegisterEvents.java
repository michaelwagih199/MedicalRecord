package com.polimigo.medicalrecord.views.events;

public interface RegisterEvents {
    public abstract void onStartedL();
    public abstract void onSuccessL();
    public abstract void onFailerL();
}

